<?php

/* @Page:C:\UniformServer\UniServerZ\www\blog\user\plugins\admin/pages/admin */
class __TwigTemplate_9004bfaad6c6bfbc51b7684dfb88957f173db2efd47e9e9b17a4872d81ab0bfd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@Page:C:\\UniformServer\\UniServerZ\\www\\blog\\user\\plugins\\admin/pages/admin";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Page:C:\\UniformServer\\UniServerZ\\www\\blog\\user\\plugins\\admin/pages/admin", "");
    }
}
