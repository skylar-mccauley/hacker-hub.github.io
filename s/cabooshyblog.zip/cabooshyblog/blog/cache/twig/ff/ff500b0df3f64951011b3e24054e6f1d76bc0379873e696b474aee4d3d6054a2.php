<?php

/* @Page:C:/UniformServer/UniServerZ/www/blog/user/pages/posts/burnout-paradise-remastered-thoughts */
class __TwigTemplate_f262c0e83a2f8b2129396ae9c1d524f473b9719cd74dec8759323dbef86f6071 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<p>tl;dr? i really hope EA dont fuck it up. Moving on,</p>
<p>So EA recently announced a remaster of one of my Favourite Burnout games besides Revenge, Paradise, it includes all 8 DLC's and Big Surf Island, which is huge, as PC never got Big Surf Island officially so this is awesome, its coming to Xbox One and PS4 on March 16th, and \"later this year\" on PC, i REALLY, REEEALLLY hope they dont add fucking microtransactions to the online, because if they do find a way to put lootboxes in it, i will not be buying it at all and will just play The Ultimate Box on Origin, because at least i can enjoy the game then.</p>
<p>but thats just the worst case, to be honest the \$40/£40 price tag is pretty steep in my opinion, but then again Bethesda charges full price for S:SE so i guess its a pill im gonna have to swallow, at the end of the day, i am really looking forward to having a burnout to play again.
<img src=\"https://caboosh.s-ul.eu/dVVcjSyF.jpg\" alt=\"\" /></p>";
    }

    public function getTemplateName()
    {
        return "@Page:C:/UniformServer/UniServerZ/www/blog/user/pages/posts/burnout-paradise-remastered-thoughts";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<p>tl;dr? i really hope EA dont fuck it up. Moving on,</p>
<p>So EA recently announced a remaster of one of my Favourite Burnout games besides Revenge, Paradise, it includes all 8 DLC's and Big Surf Island, which is huge, as PC never got Big Surf Island officially so this is awesome, its coming to Xbox One and PS4 on March 16th, and \"later this year\" on PC, i REALLY, REEEALLLY hope they dont add fucking microtransactions to the online, because if they do find a way to put lootboxes in it, i will not be buying it at all and will just play The Ultimate Box on Origin, because at least i can enjoy the game then.</p>
<p>but thats just the worst case, to be honest the \$40/£40 price tag is pretty steep in my opinion, but then again Bethesda charges full price for S:SE so i guess its a pill im gonna have to swallow, at the end of the day, i am really looking forward to having a burnout to play again.
<img src=\"https://caboosh.s-ul.eu/dVVcjSyF.jpg\" alt=\"\" /></p>", "@Page:C:/UniformServer/UniServerZ/www/blog/user/pages/posts/burnout-paradise-remastered-thoughts", "");
    }
}
