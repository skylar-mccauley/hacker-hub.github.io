<?php

/* @Page:C:/UniformServer/UniServerZ/www/blog/user/pages/posts */
class __TwigTemplate_c38c2a6fbff1de014143e9eee433f84b63496ad17f1eb979b883a5c5ee6bba00 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@Page:C:/UniformServer/UniServerZ/www/blog/user/pages/posts";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Page:C:/UniformServer/UniServerZ/www/blog/user/pages/posts", "");
    }
}
