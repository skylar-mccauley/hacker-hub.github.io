<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/UniformServer/UniServerZ/www/blog/user/plugins/blog-injector/blog-injector.yaml',
    'modified' => 1519038604,
    'data' => [
        'enabled' => true,
        'framework' => 'pure',
        'add_default_css' => true,
        'add_framework_assets' => true
    ]
];
