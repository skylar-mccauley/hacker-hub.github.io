<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/UniformServer/UniServerZ/www/blog/user/plugins/admin-addon-user-manager/admin-addon-user-manager.yaml',
    'modified' => 1519038538,
    'data' => [
        'enabled' => true,
        'default_list_style' => 'list',
        'pagination' => [
            'per_page' => 20
        ]
    ]
];
