<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/UniformServer/UniServerZ/www/blog/user/plugins/pagination/pagination.yaml',
    'modified' => 1519038592,
    'data' => [
        'enabled' => true,
        'built_in_css' => true,
        'delta' => 0
    ]
];
