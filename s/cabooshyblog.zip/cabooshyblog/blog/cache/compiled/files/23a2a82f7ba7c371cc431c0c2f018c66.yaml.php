<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/UniformServer/UniServerZ/www/blog/user/plugins/problems/problems.yaml',
    'modified' => 1512532072,
    'data' => [
        'enabled' => true,
        'built_in_css' => true
    ]
];
