<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/UniformServer/UniServerZ/www/blog/user/plugins/taxonomylist/taxonomylist.yaml',
    'modified' => 1519038594,
    'data' => [
        'enabled' => true,
        'route' => '/blog'
    ]
];
