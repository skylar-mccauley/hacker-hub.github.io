<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://breadcrumbs/breadcrumbs.yaml',
    'modified' => 1519038598,
    'data' => [
        'enabled' => true,
        'show_all' => true,
        'built_in_css' => true,
        'include_home' => true,
        'include_current' => true,
        'icon_home' => '',
        'icon_divider_classes' => 'fa fa-angle-right',
        'link_trailing' => false
    ]
];
