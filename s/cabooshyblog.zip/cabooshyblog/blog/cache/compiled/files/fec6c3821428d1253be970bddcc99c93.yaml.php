<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://taxonomylist/taxonomylist.yaml',
    'modified' => 1519038594,
    'data' => [
        'enabled' => true,
        'route' => '/blog'
    ]
];
