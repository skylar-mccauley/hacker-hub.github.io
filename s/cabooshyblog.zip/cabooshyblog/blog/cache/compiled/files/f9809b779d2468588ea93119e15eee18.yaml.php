<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'themes://dup-blog/dup-blog.yaml',
    'modified' => 1512532074,
    'data' => [
        'enabled' => true,
        'dropdown' => [
            'enabled' => false
        ]
    ]
];
