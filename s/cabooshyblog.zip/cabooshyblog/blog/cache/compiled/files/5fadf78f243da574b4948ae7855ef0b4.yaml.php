<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/UniformServer/UniServerZ/www/blog/user/accounts/cabooshy.yaml',
    'modified' => 1519038270,
    'data' => [
        'email' => 'cambomiller@googlemail.com',
        'fullname' => 'Cameron Miller',
        'title' => 'Blog Owner',
        'state' => 'enabled',
        'access' => [
            'admin' => [
                'super' => 'true',
                'login' => 'true'
            ],
            'site' => [
                'login' => 'true'
            ]
        ],
        'hashed_password' => '$2y$10$Tb3dD9IrSlGHUlWDVCP6lujjj0kkyk1lKDkJkbO9kwJHRzL3Q.g8m',
        'authorized' => true,
        'twofa_secret' => 'NCEEGNOUZ4AIUCFIGUMPJCPGIFHKOXRI',
        'language' => 'en',
        'twofa_enabled' => false,
        'avatar' => [
            'user/accounts/avatars/d4ETFUyI6GYk58e.png' => [
                'name' => 'd4ETFUyI6GYk58e.png',
                'type' => 'image/png',
                'size' => 4626717,
                'path' => 'user/accounts/avatars/d4ETFUyI6GYk58e.png'
            ]
        ]
    ]
];
