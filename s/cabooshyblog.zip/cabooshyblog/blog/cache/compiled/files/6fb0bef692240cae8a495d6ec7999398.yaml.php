<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/UniformServer/UniServerZ/www/blog/user/plugins/feed/feed.yaml',
    'modified' => 1519038588,
    'data' => [
        'enabled' => true,
        'limit' => 10,
        'description' => 'My Feed Description',
        'lang' => 'en-us',
        'length' => 500,
        'enable_json_feed' => false
    ]
];
