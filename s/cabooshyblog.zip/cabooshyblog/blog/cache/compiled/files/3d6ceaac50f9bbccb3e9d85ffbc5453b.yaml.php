<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'C:/UniformServer/UniServerZ/www/blog/user/config/streams.yaml',
    'modified' => 1519037798,
    'data' => [
        
    ]
];
