/*
 
  ________  ________  _______   ________  ________  ________  ________  ________  ___      ___ _______      
 |\   __  \|\   ____\|\  ___ \ |\   __  \|\   __  \|\   __  \|\   __  \|\   __  \|\  \    /  /|\  ___ \     
 \ \  \|\  \ \  \___|\ \   __/|\ \  \|\  \ \  \|\  \ \  \|\  \ \  \|\  \ \  \|\  \ \  \  /  / | \   __/|    
  \ \   __  \ \  \  __\ \  \_|/_\ \   __  \ \   ____\ \   ____\ \   _  _\ \  \\\  \ \  \/  / / \ \  \_|/__  
   \ \  \ \  \ \  \|\  \ \  \_|\ \ \  \ \  \ \  \___|\ \  \___|\ \  \\  \\ \  \\\  \ \    / /   \ \  \_|\ \ 
    \ \__\ \__\ \_______\ \_______\ \__\ \__\ \__\    \ \__\    \ \__\\ _\\ \_______\ \__/ /     \ \_______\
     \|__|\|__|\|_______|\|_______|\|__|\|__|\|__|     \|__|     \|__|\|__|\|_______|\|__|/       \|_______|
                                                                                                            
                                                                                                            
*/                                                                                                                                                                    
 
const fs = require("fs");
fs.readFile(`./data/brain/startup.txt`, 'utf8', function(err, data) {
  console.log(data)
})


const pusage = require('pidusage')
const moment = require('moment')
const Discord = require("discord.js");
const RichEmbed = require("discord.js").RichEmbed;
const client = new Discord.Client({autoReconnect:true});
const boxen = require('boxen')
const ms = require('ms')
const config = require('./data/brain/config.json')
const prefix = config.prefix
const token = config.token

/* This bot was made by TheHacker. This code can be used for educational purposes.
Please don't be a skid */


client.on("message", (message) => {

  const args = message.content.split(" ");
  const command = message.content.split(" ")[0]
  if(message.author.bot) return;
  if(message.channel.type === 'dm') return;
  if(!command.startsWith(prefix)) return;
  const cmd = client.commands.get(command.slice(prefix.length))
  if(cmd)
    cmd.run(client, message, args, config)
})

client.on("message", (message) => {
    if(message.author.bot) return;
    if(message.channel.type === 'dm') return;
    if(message.content.startsWith(`<@${client.user.id}>`)) {
      var mentionedembed = new Discord.RichEmbed()
        .setColor(config.color)
        .setTitle('Prefix')
        .setDescription('```' + prefix + '```')
        .setFooter(prefix + 'help')
        message.channel.send({embed: mentionedembed})
    }
  })
  client.commands = new Discord.Collection();
  fs.readdir("./data/commands", (err, files) => {
    if(err) console.error(err)
    const jsFiles = files.filter(f => f.split(".").pop() === "js")
    if(jsFiles.length <= 0) {
      console.log("No commands loaded")
      return;
    }
    console.log('[Commands Loaded] ' + jsFiles.length)

    jsFiles.forEach((f, i) => {
      const props = require("./data/commands/" + f)
      client.commands.set(props.help.name, props)
    })
  })
  client.on("ready", () => {
    
    console.log('[Logged in] ' + client.user.tag)
    console.log('[Time] ' + moment().format('MMMM Do YYYY, h:mm:ss a'))
    console.log('[Game]', config.game)
    console.log('[Activity]', config.activity)
  client.user.setActivity(config.game + ' | ' + config.prefix + 'help', { type: config.activity })

});

client.on('disconnect', event => {
    console.log('[DISCONNECTED] Attempting to reconnecting')
    client.destroy()
    client.login(token)
  })

  
  client.on('guildMemberAdd', member => {
    var notifyChannel = member.guild.channels.find('name', config.notifyChnl)
    var notifyChannelExists = member.guild.channels.exists('name', config.notifyChnl)

    if(!notifyChannelExists) return console.log('[ERROR] NotifyChannel does not exist. Please edit config.notifyChnl in data/brain/')


    var notifyMessage = `Welcome ` + member +  `! Please use the f.age command to verify your age.`

    notifyChannel.send(notifyMessage)

  });

    client.login(token)