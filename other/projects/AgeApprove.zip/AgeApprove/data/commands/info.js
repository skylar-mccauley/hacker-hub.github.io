const prettyMs = require('pretty-ms');
const RichEmbed = require("discord.js").RichEmbed;
const Attachment = require("discord.js").Attachment;
const Discord = require("discord.js");
const boxen = require('boxen');
const fs = require('fs')
module.exports.run = (client, message, args, config) => {

var infosembed = new Discord.RichEmbed()
    .setColor(config.colors)
    .setTitle(client.user.username + ' Info')
    .addField('Bot Creator', '`' + client.users.get('270375857384587264').tag + '`', true)
    .addField('Bot & Server Owner', '`' + client.users.get('273169968202252289').tag + '`', true)
    .addField('Library', '[DiscordJS](https://discord.js.org/)', true )
    .addField('Language', '[NodeJS](https://nodejs.org/)', true)
    .addField('Uptime', prettyMs(client.uptime, {verbose: true}), true)
    .addField('Bot Creator Website', '[HackerHub](https://hacker-hub.com/)',true)
    .addField('Bot Download', '[Download](https://hacker-hub.com/other/#ageapprove)')
    .setThumbnail(client.user.displayAvatarURL)
    //.setImage('https://i.imgur.com/ZfQo3rY.gif')
    .setAuthor(client.user.username, client.user.displayAvatarURL)
    // removed 


    message.channel.send({embed: infosembed})
}
module.exports.help = {
  name: "info",
  info: "Get info on Sunset",
  usage: "info"
}
