const RichEmbed = require("discord.js").RichEmbed;
const Attachment = require("discord.js").Attachment;
const Discord = require("discord.js");
const boxen = require('boxen');
const fs = require('fs')
module.exports.run = (client, message, args, config) => {

    if(!fs.existsSync('./data/age/' + message.author.id + '.age.txt')) {
        fs.writeFile(`./data/age/${message.author.id}.age.txt`, 'noAge', function(err) {
            if(err) return message.channel.send('An error occured while trying to write file: ' + err)
        });
    }

    var otherUserAge = message.guild.member(message.mentions.users.first());
    const sfwRole = message.guild.roles.find('name', config.SFWrole)
    const sfwRoleExists = message.guild.roles.exists('name', config.SFWrole)
    const nsfwRole = message.guild.roles.find('name', config.NSFWrole)
    const nsfwRoleExists = message.guild.roles.exists('name', config.NSFWrole)

    var userAge = message.member
    var option = args[1]
    var age = args[2]

    if(!sfwRoleExists) return message.channel.send('SFW Role does not exist `data/brain/config.json:SFWrole`')
    if(!nsfwRoleExists) return message.channel.send('NSFW Role does not exists `data/brain/config.json:NSFWrole`')

    var ageHelp = new Discord.RichEmbed()
        .setColor(config.colors)
        .setTitle('Age Help')
        .setDescription('Verify your age on the server. **Any use of this system is a bannable offense**\n\n' + 
                        '**Verify Age**\n' + 
                        '`age verify <age>`\n' +
                        '**Find another member\'s age**\n' +
                        '`age user <@user>`\n' + 
                        'To re-verify your age use the `age verify` once more')

    if(message.content.split(' ').slice(1).join(' ').length < 1) return message.channel.send({embed: ageHelp})


   if(option.includes('verify')) {

            var noAge = new Discord.RichEmbed() 
                .setColor(config.colors)
                .setDescription('No Age Provided')
            var notAnAge = new Discord.RichEmbed()
                .setColor(config.colors)
                .setDescription('The Age provided, `' + age + '`, is not a number')
            if(!age) return message.channel.send({embed: noAge})
            
            if(isNaN(age)) return message.channel.send({embed: notAnAge})

            var parsedAge = parseFloat(age)

            fs.writeFile(`./data/age/${message.author.id}.age.txt`, parsedAge, function(err) {
                if(err) return message.channel.send('An error occured while trying to write age to file: ' + err)
                if(parsedAge < 13) {
                    if(!message.member.kickable) return message.channel.send('**Could not kick underage member**')
                    var againstTOS = new Discord.RichEmbed()
                        .setColor(config.colors)
                        .setTitle('ATTENTION')
                        .setDescription('You are an underage Discord user. This is against TOS and therefore you cannot stay on this server.')
                        message.member.send({embed: againstTOS}).then( () => {
                            if (!message.guild.me.hasPermission('KICK_MEMBERS')) return message.channel.send('**Could not kick underage member**')
                            message.member.kick('Underage (<13)')
                        })
                        return;
                }
                if(parsedAge < 15) {
                    if (!message.guild.me.hasPermission('MANAGE_ROLES')) return message.channel.send('**Could not add SFW Role (MANAGE_ROLES permission required)**')
                    message.member.addRole(sfwRole).catch(err => {
                        return message.channel.send('An error occured while trying to apply SFW Role: ' + err)
                    })
                    if(message.member.roles.has(nsfwRole.id)) {
                        message.member.removeRole(nsfwRole.id).catch(err => {
                            return message.channel.send('An error occured while trying to remove NSFW Role: ' + err)
                        })
                    }
                    var sfwRoleSuccess = new Discord.RichEmbed()
                        .setColor(config.colors)
                        .setTitle('Your age is now verified!')
                        .setDescription('You have received the ' + config.SFWrole + ' role and can now access SFW channels')
                        
                    return message.channel.send({embed: sfwRoleSuccess})
                }
                if(parsedAge >=15) {
                    if (!message.guild.me.hasPermission('MANAGE_ROLES')) return message.channel.send('**Could not add NSFW Role (MANAGE_ROLES permission required)**')
                    message.member.addRole(nsfwRole).catch(err => {
                        message.channel.send('An error occured while trying to apply NSFW Role: ' + err)

                    });
                    if(message.member.roles.has(sfwRole.id)) {
                        message.member.removeRole(sfwRole.id).catch(err => {
                            return message.channel.send('An error occured while trying to remove SFW Role: ' + err)
                        })
                    }
                var nsfwRoleSuccess = new Discord.RichEmbed()   
                    .setColor(config.colors)
                    .setTitle('Your age is now verified!')
                    .setDescription('You have received the ' + config.NSFWrole + ' role and can now access NSFW channels')
                        return;
                }

             });


        }  else if(option.includes('user')) { 
            var noAgeForUser = new Discord.RichEmbed()
            .setColor(config.colors)
            .setTitle('No Age Found')
            .setDescription('The member ' + otherUserAge + ' does not exist in the age database.')

        if(!fs.existsSync(`./data/age/${otherUserAge.user.id}.age.txt`)) return message.channel.send({embed: noAgeForUser})

        fs.readFile(`./data/age/${otherUserAge.user.id}.age.txt`, function(err, data) {
            if(err) return message.channel.send('An error occured while trying to read another member\'s age file: '  + err)
            var otherAge = new Discord.RichEmbed()
                .setColor(config.colors)
                .setDescription('**Age:** ' + data)
                .setAuthor(otherUserAge.user.tag, otherUserAge.user.displayAvatarURL)
                return message.channel.send({embed: otherAge})
        })
        } else {
            var notValid = new Discord.RichEmbed()
            .setColor(config.colors)
            .setTitle('Option Not Valid')
            .setDescription('The option `' + option + '` is not valid. Please try again.')
        return message.channel.send({embed: notValid})
        }
        // If another user is provided

       


}
module.exports.help = {
    name: "age",
    info: "Age verification",
    usage: "age <@user|verify> <age (if verify is used>"
}