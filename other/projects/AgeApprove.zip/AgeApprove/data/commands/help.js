const prettyMs = require('pretty-ms');
const RichEmbed = require("discord.js").RichEmbed;
const Attachment = require("discord.js").Attachment;
const Discord = require("discord.js");
const boxen = require('boxen');
const fs = require('fs')
module.exports.run = (client, message, args, config) => {

    var help = new Discord.RichEmbed()
        .setColor(config.colors)
        .setTitle(client.user.username + ' Help')
        .setDescription('**help** - `Documentation on ' + client.user.username + '\'s commands`\n' +
                        '**info** - `Info on ' + client.user.username + '`\n' +
                        '**age** - `Verify your age and view other member\'s age`')
        .setAuthor(client.user.username, client.user.displayAvatarURL)
                        message.channel.send({embed: help})

} 
module.exports.help = {
    name: "help",
    info: "Documetation on AgeApprove's commands",
    usage: "help"
}