const prettyMs = require('pretty-ms');
const RichEmbed = require("discord.js").RichEmbed;
const Attachment = require("discord.js").Attachment;
const Discord = require("discord.js");
const boxen = require('boxen');
const fs = require('fs')
module.exports.run = (client, message, args, config) => {

    process.exit(0)

}
module.exports.help = {
    name: "restart"
}