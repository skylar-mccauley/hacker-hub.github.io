const fs = require("fs");
const fse = require("fs-extra")
fs.readFile(`./data/brain/startup.txt`, 'utf8', function(err, data) {
    console.log(data)
  })

  const Discord = require("discord.js");
  const RichEmbed = require("discord.js").RichEmbed;
  const Attachment = require("discord.js").Attachment;

  const moment = require('moment')

  const client = new Discord.Client({autoReconnect:true});
  const config = require("./data/brain/config.json");
  const prefix = config.prefix
  const token = config.token

  // Made by TheHacker#9367
  // Visit https://hacker-hub.github.io/ for more info
  // Expose X support bot requested by Corbs#0001

  /* By using this bot you agree to let me, TheHacker#9367 to
    advertise my server through this bot (unintrusively ofc).
    You also allow me to post this bot's source anywhere on
    GitHub and HackerHub. If you do not agree to these and any
    other terms, cease operation of this bot.*/

  client.on("message", (message) => {

    const args = message.content.split(" ");
    const command = message.content.split(" ")[0]
    if(message.author.bot) return;
    if(message.channel.type === 'dm') return;
    if(!command.startsWith(prefix)) return;
    const cmd = client.commands.get(command.slice(prefix.length))
    if(cmd)
      cmd.run(client, message, args, config)
  })
  client.on("error", (error) => {
    console.log('A WebSocket error has occured: ' + error)
    });

    client.on("message", (message) => {

        if(message.author.bot) return;
        if(message.channel.type === 'dm') return;
        if(message.content.startsWith(`<@${client.user.id}>`)) {
          var mentionedembed = new Discord.RichEmbed()
            .setColor(colors.system)
            .setTitle('Prefix')
            .setDescription('```' + prefix + '```')
            .setFooter(prefix + 'help')
            message.channel.send({embed: mentionedembed})
        }
    });
    client.commands = new Discord.Collection();
  fs.readdir("./data/commands", (err, files) => {
    if(err) console.error(err)
    const jsFiles = files.filter(f => f.split(".").pop() === "js")
    if(jsFiles.length <= 0) {
      console.log("No commands loaded")
      return;
    }
    console.log('[Commands Loaded] ' + jsFiles.length)

    jsFiles.forEach((f, i) => {
      const props = require("./data/commands/" + f)
      client.commands.set(props.help.name, props)
    })
  })
  client.on("ready", () => {
    
    console.log('[Logged in] ' + client.user.tag)
    console.log('[Time] ' + moment().format('MMMM Do YYYY, h:mm:ss a'))
    console.log('[Beta Role ID] ' + config.betaRoleName)
    console.log('[Developer Role ID] ' + config.developerRoleName)
    client.user.setActivity(config.game + ' | ' + config.prefix + 'help', { type: config.activity })


  });
  client.on('disconnect', event => {
    console.log('[DISCONNECTED] Attempting to reconnecting')
  })
  client.login(token)

