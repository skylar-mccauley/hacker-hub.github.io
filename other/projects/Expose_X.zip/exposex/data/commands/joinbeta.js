const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
module.exports.run = (client, message, args, config) => {
const betaRole = message.guild.roles.find('name', config.betaRoleName)
const betaRoleExists = message.guild.roles.exists('name', config.betaRoleName)

  var noBetaRole = new Discord.RichEmbed()
    .setColor(config.color)
    .setDescription('The Beta Role <@&'+ betaRole.id + '> does not exist')
  var hasBetaRole = new Discord.RichEmbed()
    .setColor(config.color)
    .setDescription('You already have the Expose X Beta Role. To leave use the `' + config.prefix + 'leavebeta` command.')
  var noPerm = new Discord.RichEmbed()
    .setColor(config.color)
    .setDescription('`MANAGE_ROLES` permission required')
if(!betaRoleExists) message.channel.send({embed: noBetaRole})
if(message.member.roles.has(betaRole.id)) return message.channel.send({embed: hasBetaRole})
if(!message.guild.me.hasPermission("MANAGE_ROLES")) return message.channel.send({embed: noPerm})

message.member.addRole(betaRole).catch(err => {
  message.channel.send('An error occured: ' + err)
})
var joinedBeta = new Discord.RichEmbed()
  .setColor(config.color)
  .setDescription('You are now apart of the Expose X Beta program. Have fun!')
  message.channel.send({embed: joinedBeta})

}
module.exports.help = {
  name: "joinbeta",
  info: "Join the Expose X beta program",
  usage: "joinbeta"
}
