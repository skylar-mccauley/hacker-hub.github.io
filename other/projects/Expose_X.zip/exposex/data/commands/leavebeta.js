const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
module.exports.run = (client, message, args, config) => {
const betaRole = message.guild.roles.find('name', config.betaRoleName)
const betaRoleExists = message.guild.roles.exists('name', config.betaRoleName)

  var noBetaRole = new Discord.RichEmbed()
    .setColor(config.color)
    .setDescription('The Beta Role <@&'+ betaRole.id + '> does not exist')
    var doesnotHaveBetaRole = new Discord.RichEmbed()
        .setColor(config.color)
        .setDescription('You do not have the Beta Role. To join use the `' + config.prefix + 'joinbeta` command.')
    var goodbye = new Discord.RichEmbed()
        .setColor(config.color)
        .setDescription('You have left the Expose X Beta Program. We hope to see you again soon! :wave:')
if(!betaRoleExists) message.channel.send({embed: noBetaRole})
if(!message.member.roles.has(betaRole.id)) return message.channel.send({embed: doesnotHaveBetaRole})

message.member.removeRole(betaRole).catch(err => {
    message.channel.send('An error has occured: ' + err)
})
    message.channel.send({embed: goodbye})
}
module.exports.help = {
  name: "leavebeta",
  info: "Leave the Expose X beta program",
  usage: "leavebeta"
}
