const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
module.exports.run = (client, message, args, config) => {
    const devRole = message.guild.roles.find('name', config.developerRoleName)
const devRoleExists = message.guild.roles.exists('name', config.developerRoleName)
    var nonDev = new Discord.RichEmbed()
        .setColor(config.color)
        .setDescription('Only Developers can use this command ( <@&' + devRole.id + '> )')
    var noDevRole = new Discord.RichEmbed()
        .setColor(config.color)
        .setDescription('The role ' + config.developerRoleName + ' does note exist')
    if(!devRoleExists) return message.channel.send({embed: noDevRole})
    if(!message.member.roles.has(devRole.id)) {
        return message.channel.send({embed: nonDev}).catch(err => {
            message.channel.send('An error occured: ' + err)
        })
    }
  var channelMention = args[1]
  var announceMessage = message.content.split(/\s+/g).slice(2).join(" ");
  var noChannel = new Discord.RichEmbed()
      .setColor(config.color)
      .setDescription('Please provide a channel to send an announcement in')
  var noMessage = new Discord.RichEmbed()
      .setColor(config.color)
      .setDescription('Please provded a message to send an announcement with')
  var channelNoExist = new Discord.RichEmbed()
      .setColor(config.color)
      .setDescription('The channel that was provided does not exist.')

  if(!channelMention) return message.channel.send({embed: noChannel})
  if(noMessage.length < 1) return message.channel.send({embed: noMessage})
  var announceChannel = channelMention.substr(2).slice(0, -1);
  var announcementChannel = client.channels.find("id", announceChannel)
  var announcementChannelExists = client.channels.exists("id", announceChannel)
  if(!announcementChannelExists) return message.channel.send({embed: channelNoExist})
  var success = new Discord.RichEmbed()
      .setColor(config.color)
      .setTitle('Announcement Sent')
      .setDescription('Announcement has been sent to ' + announcementChannel)
  
  message.channel.send({embed: success})
  announcementChannel.send(announceMessage)
}
module.exports.help = {
  name: "announce",
  info: "Make an announcement in another channel",
  usage: "announce <#channel> <message>"
}
