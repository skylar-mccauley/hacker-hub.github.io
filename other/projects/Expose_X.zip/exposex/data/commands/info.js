const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
module.exports.run = (client, message, args, config) => {
  var exposeinfo = new Discord.RichEmbed()
    .setColor(config.color)
    .setTitle(client.user.username + ' Info')
    .addField('Bot Owner', '`' + client.users.get('270375857384587264').tag +'`', true)
    .addField('Host', '[Raspberry Pi 3](https://www.raspberrypi.org/products/raspberry-pi-3-model-b/)', true)
    .addField('Library', '[Discord.JS](https://discord.js.org/)', true )
    .addField('Language', '[NodeJS](https://nodejs.org/)', true)
    .addField('Sunset Server Invite', '[Sunset Server Invite](https://hacker-hub.github.io/sunset/serverinvite/)', true)
    .setThumbnail(client.user.displayAvatarURL)
    .setAuthor(client.user.username, client.user.displayAvatarURL)
    message.channel.send({embed: exposeinfo})
}
module.exports.help = {
  name: "info",
  info: "Get info on the Expose X bot",
  usage: "info"
}
