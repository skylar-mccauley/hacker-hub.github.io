const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
module.exports.run = (client, message, args, config) => {
  var exposexhelp = new Discord.RichEmbed()
    .setColor(config.color)
    .setTitle(client.user.username + ' Commands')
    .setDescription('**help** - `Get documentation on Expose X\'s Commands`\n' + 
                    '**info** - `Info on Expose X`\n' + 
                    '**announce** - `Send an announcement in another channel`\n' +
                    '**joinbeta** - `Join the Expose X Beta Program`\n' +
                    '**leavebeta** - `Leave the Expose X Beta Program`' )
                    message.channel.send({embed: exposexhelp})
}
module.exports.help = {
  name: "help",
  info: "Get documentation on the Expose X bot's commands",
  usage: "help"
}
