const Discord = require("discord.js");
const client = new Discord.Client({autoReconnect:true});
const fs = require("fs");
const moment = require("moment")
const Attachment = require('discord.js').Attachment
const momenttimedate = moment().format('h:mm:ss a') + ' on ' +  moment().format('MMMM Do YYYY')
const data = require('./data/brain/data.json')
const announcement =  require('./data/brain/announcement.json')
const game = require('./data/brain/game.json')
const token = data.token
const prefix = data.prefix

client.on('disconnect', event => {
  console.log('[DISCONNECTED] Attempting to reconnecting')
  client.login(token)
})
client.on('error', (error) => {
console.log('A WebSocket error has occured: ' + error)
});

client.on("ready", () => {
  console.log("Supporting the land of Alpexia")
  console.log("[Name] " + client.user.tag)
  console.log("[Announcement] " + announcement.announce )
  console.log("[Game] " + game.game)
  console.log("[Activity] " + game.activity)
  if(game.activity.includes('PLAYING')) {
    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'PLAYING' })
    return;
}
if(game.activity.includes('STREAMING')) {
    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'STREAMING' })
    return;
}
if(game.activity.includes('LISTENING')) {
    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'LISTENING' })
    return;
}
if(game.activity.includes('WATCHING')) {
    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'WATCHING' })
    return;
}
});
/* client.on("message", (message) => {
  if(message.content.startsWith(`<@${client.user.id}>`)) {
    var mentionedembed = new Discord.RichEmbed()
      .setColor(embedcolor)
      .setTitle('Prefix')
      .setDescription('```' + prefix + '```')
      .addField('Authorized User 1', client.users.get(authorizedUser1).username + "#" + client.users.get(authorizedUser1).discriminator, true)
      .addField('Authorized User 2', client.users.get(authorizedUser2).username + "#" + client.users.get(authorizedUser2).discriminator, true)
      .addField('Authorized User 3', client.users.get(authorizedUser3).username + "#" + client.users.get(authorizedUser3).discriminator, true)
      .addField('Authorized User 4', client.users.get(authorizedUser4).username + "#" + client.users.get(authorizedUser4).discriminator, true) 
      message.channel.send({embed: mentionedembed})
  }
}) */
client.on("message", (message) => {
  
  const args = message.content.split(" ");
    const command = message.content.split(" ")[0]
    if(message.author.bot) return;
    if(message.channel.type === 'dm') return;
    if(!command.startsWith(prefix)) return;
    const cmd = client.commands.get(command.slice(prefix.length))
    if(cmd)
      cmd.run(client, message, args, data, game, announcement)
  })
      client.on("message", (message) => {
        if(message.content.startsWith(`<@${client.user.id}>`)) {
          var mentionedembed = new Discord.RichEmbed()
            .setColor(data.embedcolor)
            .setTitle('Prefix')
            .setDescription('```' + prefix + '```')
            message.channel.send({embed: mentionedembed})
        }
      })
      /*client.on("message", function(message) {
        var Attachment = (message.attachments).array();
        Attachment.forEach(function(attachment) {
          console.log(attachment.url);
        })
      }) */
      
      client.commands = new Discord.Collection();
    fs.readdir("./data/commands", (err, files) => {
      if(err) console.error(err)
      const jsFiles = files.filter(f => f.split(".").pop() === "js")
      if(jsFiles.length <= 0) {
        console.log("No commands loaded")
        return;
      }
      console.log('[Commands Loaded] ' + jsFiles.length)
  
      jsFiles.forEach((f, i) => {
        const props = require("./data/commands/" + f)
        client.commands.set(props.help.name, props)
      })
    })
client.login(token)
