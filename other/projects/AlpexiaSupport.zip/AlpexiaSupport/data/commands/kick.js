const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
module.exports.run = (client, message, args, data, game, announcement) => {
    let kickreason = message.content.split(/\s+/g).slice(2).join(" ");
    let kickMember = message.guild.member(message.mentions.users.first());
    var announcements = message.guild.channels.find('name', 'announcements');
  
    var embedkreturn = new Discord.RichEmbed()
      .setColor(data.embedcolor)
      .setDescription('You need to provide a member to kick and a reason for the kick')
      .addField(prefix + 'kick <@user> <reason>','<@user> = Mentioned User | <reason> = Reason for Kick')
      .setFooter(momenttimedate)
    var embedkpermreturn = new Discord.RichEmbed()
   .setColor(data.embedcolor)
   .setTitle('Kick Usage')
   .setDescription('This command will only work if you have the permission `KICK_MEMBERS`')
   .addField(prefix + 'kick <@user> <reason>','<@user> = Mentioned User | <reason> = Reason for Kick')
   var embedbotkpermreturn = new Discord.RichEmbed()
    .setColor(data.embedcolor)
    .setTitle('Kick Usage')
    .setDescription('This command will only work if I have the permission `KICK_MEMBERS`')
    .addField(prefix + 'kick <@user> <reason>','<@user> = Mentioned User | <reason> = Reason for Kick')
    .setFooter(momenttimedate)
  
      if (!message.member.hasPermission('KICK_MEMBERS')) return message.channel.send({embed: embedkpermreturn}).catch(console.error);
      if(!message.guild.me.hasPermission('KICK_MEMBERS')) return message.channel.send({embed: embedbotkpermreturn}).catch(console.error);
      var newembed = new Discord.RichEmbed()
      .setColor(data.embedcolor)
      .setTitle('Kick Usage')
      .setDescription('You provide a member to kick and a reason')
      .addField(prefix + 'kick <@user> <reason>','<@user> = Mentioned User | <reason> = Reason for kick')
      var sunsetkickembed = new Discord.RichEmbed()
        .setColor(data.embedcolor)
        .setTitle('Kick Usage Error')
        .setDescription('I cannot kick myself :joy:')
        .addField(prefix + 'kick <@user> <reason>','<@user> = Mentioned User | <reason> = Reason for kick')
        .setFooter(momenttimedate)
  
  
        if(kickreason.length < 1) return message.channel.send({embed: newembed}).catch(console.error);
        if(kickMember.length < 1) return message.channel.send({embed: newembed}).catch(console.error);mbedaction = new Discord.RichEmbed()
        .setColor(data.embedcolor)
        .setDescription('**A user has been Kicked** \n \n **User:** ' + kickMember + '\n **Moderator:** ' + message.author.username + ' \n **Reason:** ' + kickreason + ' \n **Server:** ' + message.guild.name)
        .setAuthor(message.author.username ,message.author.avatarURL)
        .setFooter(momenttimedate)
        message.channel.send({embed: embedaction}).catch(console.error);
            message.delete()
            message.guild.member(kickMember).kick(kickreason);
}
module.exports.help = {
    name: "kick",
    info: "Kicks the mentioned user",
    usage: "kick <@user> <reason>"
}