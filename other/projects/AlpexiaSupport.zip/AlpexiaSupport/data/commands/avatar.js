const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
const boxen = require("boxen")
module.exports.run = (client, message, args, data, game, announcement) => {
let useravatar = message.content.split(' ').slice(1).join(' ')
let otheruser = message.guild.member(message.mentions.users.first())
var useravatarlengthtooshortembed = new Discord.RichEmbed()
  .setColor(data.embedcolor)
  .setTitle('Avatar Help')
  .setDescription('You must provide a mentioned user')
  .addField(data.prefix + 'avatar <@user>','<@user> =  Mentioned User')
  // removed 
var avatarnomenembed = new Discord.RichEmbed()
  .setColor(data.embedcolor)
  .setTitle('Avatar of ' + message.author.username)
  .setImage(message.author.displayAvatarURL)
  .setAuthor(message.author.username ,message.author.displayAvatarURL)
  // removed 

if(useravatar.length < 1) return message.channel.send({embed: avatarnomenembed})

  var avatarouembed = new Discord.RichEmbed()
    .setColor(data.embedcolor)
    .setTitle(' ')
    .setImage(message.mentions.users.first().displayAvatarURL)
    .setAuthor(message.author.username ,message.author.displayAvatarURL)
    // removed 
    message.channel.send({embed: avatarouembed}).catch(console.error);
  }
  module.exports.help = {
    name: "avatar",
    info: "Get your own avatar *or the mentioned user*",
    usage: "avatar <@user>"
  }
