const Discord = require("discord.js")
const RichEmbed = require("discord.js").RichEmbed
module.exports.run = (client, message, args, data, game, announcement) => {
    if(message.author.id == data.botownerid) {
        const bcmds = ',rules ,help, ,ban ,unban ,kick ,purge ,informuser ,setnick ,avatar ,profile ,settings ,announcement ,ping ,restart'
       // var announcement = require("./data/brain/announcement.json");
        var bohelpembed = new Discord.RichEmbed()
          .setColor(data.embedcolor)
          .setTitle('Help')
          .addField('**Commands**', '```' + bcmds + '```')
          .addField('**Announcement**', '```' + announcement.announce + '```')
          message.channel.send({embed: bohelpembed})
      }
      if(message.author.id !== data.botownerid) {
        const regcmds = ',rules ,help, ,ban ,unban ,kick ,purge ,informuser ,setnick ,avatar ,profile ,settings ,announcement ,ping'
     //   var announcement = require("./data/brain/announcement.json");
        var reghelpembed = new Discord.RichEmbed()
        .setColor(data.embedcolor)
        .setTitle('Help')
        .addField('**Commands**', '```' + regcmds + '```')
        .addField('**Announcement**', '```' + announcement.announce + '```')
        message.channel.send({embed: reghelpembed})
      }
}
module.exports.help = {
    name: "help",
    info: "Get documentation on all of Instinct Support\'s commands",
    usage: "help <command>"
}