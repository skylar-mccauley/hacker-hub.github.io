const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
module.exports.run = (client, message, args, data, game, announcement) => {
    let banmessage = message.content.split(' ').slice(1).join(' ')
    let banMember = message.guild.member(message.mentions.users.first());
      let banreason = message.content.split(/\s+/g).slice(2).join(" ");
    var embedreturn = new Discord.RichEmbed()
      .setColor(data.embedcolor)
      .setDescription('You need to provide a member to ban and a reason for the ban')
      .addField(prefix + 'ban <@user> <reason>','<@user> = Mentioned User | <reason> = Reason for Ban')
      .setFooter(momenttimedate)
    var embedpermreturn = new Discord.RichEmbed()
    .setColor(data.embedcolor)
    .setTitle('Ban Usage')
    .setDescription('This command will only work if you have the permission `BAN_MEMBERS`')
    .addField(prefix + 'ban <@user> <reason>','<@user> = Mentioned User | <reason> = Reason for Kick')
    var embedbotpermreturn = new Discord.RichEmbed()
    .setColor(data.embedcolor)
    .setTitle('Ban Usage')
    .setDescription('This command will only work if I have the permission `BAN_MEMBERS`')
    .addField(prefix + 'ban <@user> <reason>','<@user> = Mentioned User | <reason> = Reason for Kick')
    .setFooter(momenttimedate)
    var banusermessageembed = new Discord.RichEmbed()
    .setColor(data.embedcolor)
    .setTitle('Automated Ban Message')
    .setDescription('**You have been banned** \n \n **Moderator:** ' + message.author.username + ' \n **Reason:** ' + banreason + ' \n **Server:** ' + message.guild.name)
      if (!message.member.hasPermission('BAN_MEMBERS')) return message.channel.send({embed: embedpermreturn}).catch(console.error);
      if(!message.guild.me.hasPermission("BAN_MEMBERS")) return message.channel.send({embed: embedbotpermreturn}).catch(console.error);
    
      //  if(!banmessage.content.indexOf('@') === '@') return message.channel.send(':(')
        if(banreason.length < 1) return message.channel.send({embed: embedreturn}).catch(console.error);
        if(banMember.length < 1) return message.channel.send({embed: embedreturn}).catch(console.error);
            message.guild.member(banMember).ban(banreason)
            message.delete()
            var embedaction = new Discord.RichEmbed()
            .setColor(data.embedcolor)
            .setDescription('**A user has been banned** \n \n **User:** ' + banMember + '\n **Moderator:** ' + message.author.username + '\n **Reason:** ' + banreason + '\n **Server:** ' + message.guild.name)
            .setAuthor(message.author.username ,message.author.avatarURL)
            .setFooter(momenttimedate)
            message.channel.send({embed: embedaction})
            client.users.get(informeduser).send({embed: embedaction}).catch(console.error);
}
module.exports.help = {
    name: "ban",
    info: "Bans the mentioned user",
    usage: "ban <@user> <reason>"
}