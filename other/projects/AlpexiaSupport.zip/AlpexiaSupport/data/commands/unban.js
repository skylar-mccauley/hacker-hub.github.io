const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
module.exports.run = (client, message, args, data, game, announcement) => {
    var permerrorubembed = new Discord.RichEmbed()
    .setColor(data.embedcolor)
    .setTitle('Unban Usage')
    .setDescription("You must have the permission `BAN_MEMBERS`")
    .addField(prefix + 'unban <userid> <reason>','<userid> = User\'s Guild ID | <reason> = Reason for Unban')
    .setFooter(momenttimedate)
  var botpermerrorubembed = new Discord.RichEmbed()
    .setColor(data.embedcolor)
    .setTitle("Unban Usage")
    .setDescription("I must have the permission `BAN_MEMBERS`")
    .addField(prefix + 'unban <userid> <reason>','<userid> = User\'s Guild ID | <reason> = Reason for Unban')
    .setFooter(momenttimedate)

    if(!message.member.hasPermission('BAN_MEMBERS')) return message.channel.send({embed: permerrorubembed}).catch(console.error);
    if(!message.guild.me.hasPermission('BAN_MEMBERS')) return message.channel.send({embed: botpermerrorubembed}).catch(console.error);
    var embedreturn = new Discord.RichEmbed()
      .setColor(data.embedcolor)
      .setTitle('Unban Usage')
      .setDescription('You must provide a reason for the UnBan')
        .addField(prefix + 'unban <userid> <reason>','<userid> = User\'s Guild ID | <reason> = Reason for Unban')
      .setFooter(momenttimedate)

let unbanMember = message.mentions.users.first();
let unbanreason = message.content.split(/\s+/g).slice(1, 2).join(" ");
if(unbanreason.length < 1) return message.channel.send(embedreturn).catch(console.error);
message.guild.unban(unbanreason);
      message.delete()
      message.channel.sendMessage("The user, " + message.author.username + "has unbanned a member.");
}
module.exports.help = {
    name: "unban",
    info: "Unban a user by ID",
    usage: "unban <userID> <reason>"
}