const Discord = require("discord.js")
const RichEmbed = require("discord.js").RichEmbed
const boxen = require("boxen")
module.exports.run = (client, message, args, data, game, announcement) => {
    if (message.author.id !== data.botownerid) return message.channel.send(`**Owner Only Command**`).catch(console.error);
    process.exit(0);
}
module.exports.help = {
    name: "restart",
    info: "Restarts the bot",
    usage: "restart"
}