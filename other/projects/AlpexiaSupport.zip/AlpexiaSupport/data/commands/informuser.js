const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
const boxen = require("boxen")
module.exports.run = (client, message, args, data, game, announcement) => {
    if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send('***You must have the `MANAGE_GUILD` permission***').catch(console.error);
    var informeduser = message.guild.member(message.mentions.users.first());
    var info = message.content.split(/\s+/g).slice(2).join(" ");
    var userinform = new Discord.RichEmbed()
      .setColor(data.embedcolor)
      .setTitle("**Important Info**")
      .setDescription(info)
      .setAuthor(message.author.username, message.author.displayAvatarURL)
      message.guild.member(message.mentions.users.first()).send({embed: userinform}).catch(console.error);
      message.channel.send('***Message sent to ' + informeduser.user.tag + '***')

} 
module.exports.help = {
    name: "informuser",
    info: "Inform a User",
    usage: "informuser <@user> <message>"
}