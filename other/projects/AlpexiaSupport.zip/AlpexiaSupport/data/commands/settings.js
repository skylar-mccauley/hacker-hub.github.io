
const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
const boxen = require('boxen');
const ms = require('ms')
const fs = require('fs')
module.exports.run = (client, message, args, data, game, announcement) => {
    const modlog = message.guild.channels.find('name', 'mod-log');
    var commandlock = data.lock
    var newstatus = client.user.presence.status.toUpperCase()
    const authUser = ['276879025224286208', '270375857384587264', '276162330700808192', '263528837885853697', '250051420022243341']
    var authorid = message.author.id
    var setting = args[1]
    var option = message.content.split(setting).slice(1).join(' ')
    var setembed = `Announcement: ${announcement.announce}\n` +
                    `Color: ${data.embedcolor}\n` +
                    `Game: ${game.game}\n` +
                    `Activity: ${game.activity}\n` +
                    `Status: ${newstatus}`
    if(!setting) {
            return message.channel.send('```' + boxen(setembed, {padding: 1}) + '```')
    }
    if(setting.includes('announcement')) {

    if(authUser.some(id => authorid.includes(id))) {
        if(!option) return;
        announcement.announce = option;
      
      fs.writeFileSync("./data/brain/announcement.json", JSON.stringify(announcement), (err) => console.error);
      message.channel.send('Set announcement to `' + option + '`')
    } else {
    
    }
        
      return;
    }
    if(setting.includes('color')) {
        if(authUser.some(id => authorid.includes(id))) {
            if(!option) return;
            data.embedcolor = option
            fs.writeFileSync("./data/brain/data.json", JSON.stringify(data), (err) => console.error);
            message.channel.send('Set embed color to `' + data.embedcolor + '`')
        } else {
            message.channel.send('You are not authorized to use this command.')
    return;
        }
        
        return;
    }
    if(setting.includes('game')) {
        if(authUser.some(id => authorid.includes(id))) {
            if(!option) return;
            
            game.game = option
            
            fs.writeFile("./data/brain/game.json", JSON.stringify(game), (err) => console.error)
                  message.delete()
                  message.channel.send('Set Game Status to `' + game.game + ' | ' + data.prefix + 'help`').catch(console.error);
                
                if(game.activity.includes('PLAYING')) {
                    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'PLAYING' })
                    return;
                }
                if(game.activity.includes('STREAMING')) {
                    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'STREAMING' })
                    return;
                }
                if(game.activity.includes('LISTENING')) {
                    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'LISTENING' })
                    return;
                }
                if(game.activity.includes('WATCHING')) {
                    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'WATCHING' })
                    return;
                }
        } else {
            message.channel.send('You are not authorized to use this command.')
    return;
        }
       

    }
    if(setting.includes('activity')) {
        if(authUser.some(id => authorid.includes(id))) {
            if(!option) return;
            var validacts = ['PLAYING', 'WATCHING', 'STREAMING', 'LISTENING']
            if(validacts.some(activities => option.includes(activities))) {
                var newoption = option.toUpperCase()
                if(newoption.includes('PLAYING')) {
    
                    game.activity = 'PLAYING'
                    fs.writeFile("./data/brain/game.json", JSON.stringify(game), (err) => console.error)
    
                    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'PLAYING' })
                    message.delete()
                  message.channel.send('Set Activity to `' + game.activity + '`').catch(console.error);
                }
                if(newoption.includes('WATCHING')) {
    
                    game.activity = 'WATCHING'
                    fs.writeFile("./data/brain/game.json", JSON.stringify(game), (err) => console.error)
    
                    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'WATCHING' })
                    message.delete()
                  message.channel.send('Set Activity to `' + game.activity + '`').catch(console.error);
                  return;
                }
                if(newoption.includes('STREAMING')) {
    
                    game.activity = 'STREAMING'
                    fs.writeFile("./data/brain/game.json", JSON.stringify(game), (err) => console.error)
    
                    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'STREAMING' })
                    message.delete()
                  message.channel.send('Set Activity to `' + game.activity + '`').catch(console.error);
                  return;
                }
                if(newoption.includes('LISTENING')) {
    
                    game.activity = 'LISTENING'
                    fs.writeFile("./data/brain/game.json", JSON.stringify(game), (err) => console.error)
    
                    client.user.setActivity(game.game + ' | ' + data.prefix + 'help', { type: 'LISTENING' })
                    message.delete()
                  message.channel.send('Set Activity to `' + game.activity + '`').catch(console.error);
                  return;
                }
            
    
            } else {
                message.channel.send('Valid Activities\n`PLAYING` `LISTENING` `WATCHING` `STREAMING`')
            }
        } else {
            message.channel.send('You are not authorized to use this command.')
    return;
        }
        
              
    }
    if(setting.includes('status')) {
        if(authUser.some(id => authorid.includes(id))) {
            if(!option) return;
            var statusoptions = ['online', 'idle', 'dnd', 'invisible']
            if(statusoptions.some(terms => option.includes(terms))) {
                client.user.setStatus(option).catch(console.error)
                message.channel.send('Status changed to `' + option + '`')
                return;
            } else {
                message.channel.send('The status must be `online`, `idle`, `dnd`, or `invisible`')
            }
        }
        } else {
            message.channel.send('You are not authorized to use this command.')
    return;
        }
        
}
module.exports.help = {
    name: "settings",
    info: "Change Sunset's settings",
    usage: "settings <setting> <option>"
}