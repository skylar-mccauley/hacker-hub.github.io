const RichEmbed = require("discord.js").RichEmbed;
const Discord = require("discord.js");
const boxen = require("boxen")
module.exports.run = (client, message, args, data, game, announcement) => {
    message.channel.send('```' + boxen('Announcement\n' + announcement.announce) + '```')
}
module.exports.help = {
    name: "announcement",
    info: "Show to current announcement",
    usage: "announcement"
}