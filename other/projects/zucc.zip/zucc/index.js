const Discord = require("discord.js");
const client = new Discord.Client({autoReconnect:true});

client.on("message", (message) => {
    function noQuestion(rando) {
        if(rando < 500) return message.channel.send({file: "images/smile.gif"});
        if(rando < 750) return message.channel.send({file: "images/smile.jpg"});
        if(rando < 900) return message.channel.send({file: "images/drink.gif"});
        if(rando < 975) return message.channel.send('I\'m sorry what was that?');
        return message.channel.send({file: "images/papersondesk.jpg"});
    }
    function Question(rando) {
        if(rando < 1000) return message.channel.send({file: "images/drink.jpg"});
        if(rando < 1500) return message.channel.send('I\'ll have to get back to you on that');
        if(rando < 1950) return message.channel.send({file: "images/smile.gif"});
        return message.channel.send({file: "images/papersondesk.jpg"});
    }
    if(message.author.bot || message.channel.type === 'dm' || message.channel.id !== '438430840314134528') return;
    if(message.content.endsWith("?")) return Question((Math.floor(Math.random() * 2000) + 1));
    return noQuestion((Math.floor(Math.random() * 2000) + 1));
});
client.login("haha you thought");